# -*- coding: utf-8 -*-

import sys

from PyQt5.QtWidgets import  QApplication, QMainWindow,QLabel

from PyQt5.QtCore import  pyqtSlot,Qt

##from PyQt5.QtWidgets import   

##from PyQt5.QtGui import QColor
import copy
import numpy as np

import matplotlib as mpl
from cycler import cycler
import colorcet as cc
from mpl_toolkits.mplot3d import axes3d

##from matplotlib import cm  #colormap

##import matplotlib.style as mplStyle

##import matplotlib.pyplot as plt


from MainWindow_ui import Ui_MainWindow


class myPlotWindow(QMainWindow):

   def __init__(self, parent=None):
      super().__init__(parent)
      self.ui=Ui_MainWindow()
      self.ui.setupUi(self)

      self.__colormap= mpl.cm.seismic
      self.__iniUI()

      mpl.rcParams['font.sans-serif']=['SimHei']
      mpl.rcParams['font.size']=10   

      mpl.rcParams['axes.unicode_minus'] =False

      self.__colorbar=None
      # self.__generateData()
      # self.__iniFigure()

      self.ui.widgetPlot.figure.canvas.setCursor(Qt.CrossCursor)
      self.ui.widgetPlot.figure.canvas.mpl_connect("motion_notify_event", self.do_canvas_mouseMove)
      self.ui.widgetPlot.figure.canvas.mpl_connect("pick_event", self.do_canvas_pick)

      self.ui.widgetPlot.figure.subplots_adjust(left=0.05,
               bottom=0.26, right=0.97, top=0.92, wspace=0.28)

      ''' Add these lines to MainWindow_ui.py '''
      # import ctypes
      # ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("myappid")


   def __iniUI(self):
      self.resize(1200, 500)

      self.__labPick=QLabel("picked artist")
      self.__labPick.setMinimumWidth(200)
      self.ui.statusBar.addWidget(self.__labPick)
      
      self.__labMove=QLabel("(x,y)=")
      self.__labMove.setMinimumWidth(200)
      self.ui.statusBar.addWidget(self.__labMove)

      self.__labCmp=QLabel("colormap=seismic")
      self.__labCmp.setMinimumWidth(200)
      self.ui.statusBar.addWidget(self.__labCmp)

      self.ui.widgetPlot.naviBar.addAction(self.ui.actSetCursor)
      self.ui.widgetPlot.naviBar.addSeparator()
      self.ui.widgetPlot.naviBar.addAction(self.ui.actQuit)

      cmList1=('viridis', 'plasma', 'inferno', 'magma', 'cividis')
      self.ui.comboCm1.addItems(cmList1)
      self.ui.comboCm1.currentTextChanged.connect(self.do_comboColormap_Changed)

      cmList2=('Greys', 'Purples', 'Blues', 'Greens', 'Oranges', 'Reds',
            'YlOrBr', 'YlOrRd', 'OrRd', 'PuRd', 'RdPu', 'BuPu',
            'GnBu', 'PuBu', 'YlGnBu', 'PuBuGn', 'BuGn', 'YlGn')
      self.ui.comboCm2.addItems(cmList2)
      self.ui.comboCm2.currentTextChanged.connect(self.do_comboColormap_Changed)

      cmList3=( 'binary', 'gist_yarg', 'gist_gray', 'gray', 'bone', 'pink',
            'spring', 'summer', 'autumn', 'winter', 'cool', 'Wistia',
            'hot', 'afmhot', 'gist_heat', 'copper')
      self.ui.comboCm3.addItems(cmList3)
      self.ui.comboCm3.currentTextChanged.connect(self.do_comboColormap_Changed)
      
      cmList4=('PiYG', 'PRGn', 'BrBG', 'PuOr', 'RdGy', 'RdBu',
            'RdYlBu', 'RdYlGn', 'Spectral', 'coolwarm', 'bwr', 'seismic')
      self.ui.comboCm4.addItems(cmList4)
      self.ui.comboCm4.currentTextChanged.connect(self.do_comboColormap_Changed)

      self.ui.comboCm5.currentTextChanged.connect(self.do_comboColormap_Changed)

      cmList2d = ('cc.glasbey', 'cc.glasbey_hv', 'cc.glasbey_cool', 'cc.glasbey_warm', 'cc.glasbey_dark', \
                  'cc.glasbey_light', 'blue', 'green', 'red', 'orange',\
                  'purple', 'black')
      self.cmDict2d = {0:cc.glasbey, 1:cc.glasbey_hv, 2:cc.glasbey_cool, 3:cc.glasbey_warm, 4:cc.glasbey_dark,\
                       5:cc.glasbey_light, 6:['#038add']*50, 7:['#2CA02C']*50, 8:['#d60000']*50, 9:['#FF7F0E']*50,\
                       10:['#ba6efd']*50, 11:['#1E1E1E']*50}
      # 6: blue, 7: green, 8:red, 9:orange, 10: purple, 11:black
      self.ui.combo2D_color.clear()
      self.ui.combo2D_color.addItems(cmList2d)

   def init_data(self, data_x, data3D):
      self.data3D = data3D
      y = np.linspace(0, data3D.shape[0] - 1, data3D.shape[0], endpoint=True)
      x = np.linspace(0, data3D.shape[1] - 1, data3D.shape[1], endpoint=True)
      x, y = np.meshgrid(x, y)
      z = data3D
      self._X = x
      self._Y = y
      self._Z = z

      self.x = data_x
      self.xyz = data3D
      self.xy = data3D

      self.ui.spinDivCount.setMinimum(0)
      self.ui.spinDivCount.setMaximum(np.max(data3D)*data3D.shape[0])

   def refresh_data(self):
      self.xyz = copy.deepcopy(self.data3D)
      interval = self.ui.spinDivCount.value()
      y = np.linspace(0, self.xyz.shape[0] * (int(interval) + 1) - 1, self.xyz.shape[0] * (int(interval) + 1), endpoint=True)
      x = np.linspace(0, self.xyz.shape[1], self.xyz.shape[1], endpoint=True)
      x, y = np.meshgrid(x, y)

      for i in range(self.xyz.shape[0] - 1, -1, -1):
         b = np.array(self.xyz[i, :].tolist() * int(interval)).reshape(int(interval), self.xyz.shape[1])
         self.xyz = np.insert(self.xyz, i, values=b, axis=0)

      self._X = x
      self._Y = y
      self._Z = copy.deepcopy(self.xyz)

      self.xy = copy.deepcopy(self.data3D)
      for i in range(len(self.data3D)):
         self.xy[i] += i * (interval/5)

   def __generateData(self):
      divCount=self.ui.spinDivCount.value()
      # x=np.linspace(-5, 5, divCount, endpoint=True)
      # y=np.linspace(-5, 5, divCount, endpoint=True)
      #
      # x,y= np.meshgrid(x, y)
      # p11=3*((1-x)**2)
      # p12=np.exp(-x**2-(y+1)**2)
      # p1=p11*p12
      #
      # p21=x/5-x**3-y**5
      # p22=np.exp(-x**2-y**2)
      # p2=-10*p21*p22
      #
      # p31=np.exp(-(x+1)**2-y**2)
      # p3=-p31/3
      #
      # self._Z=p1+p2+p3
      # self._X=x
      # self._Y=y

   def iniFigure(self):
      self.ui.widgetPlot.figure.clear()
      gs=self.ui.widgetPlot.figure.add_gridspec(1,2)


   ##      self.ax3D=self.ui.widgetPlot.figure.add_subplot(1,2,1,projection='3d',label="plot3D")
      self.ax3D=self.ui.widgetPlot.figure.add_subplot(
               gs[0,0],projection='3d',label="plot3D")
   ##      self.ax3D.set_xlabel("axis-X")
   ##      self.ax3D.set_ylabel("axis-Y")
   ##      self.ax3D.set_zlabel("axis-Z")

   ##      self.ax2D=self.ui.widgetPlot.figure.add_subplot(1,2,2,label="plot2D")
      self.ax2D=self.ui.widgetPlot.figure.add_subplot(gs[0,1],label="plot2D")
   ##      self.ax2D.set_xlabel("axis-X")
   ##      self.ax2D.set_ylabel("axis-Y")


   @pyqtSlot()
   def on_actSetCursor_triggered(self):  
      self.ui.widgetPlot.figure.canvas.setCursor(Qt.CrossCursor)

   @pyqtSlot()
   def on_btnRefreshData_clicked(self):  
      # self.__generateData()
      self.refresh_data()
      self.on_combo3D_type_currentIndexChanged(self.ui.combo3D_type.currentIndex())
      self.on_combo2D_color_currentIndexChanged(self.ui.combo2D_color.currentIndex())
      self.ui.chkBox3D_invertZ.setChecked(False)
      self.ui.chkBox3D_gridOn.setChecked(True)
      self.ui.chkBox3D_axisOn.setChecked(True)

   @pyqtSlot(bool)
   def on_chkBox3D_invertZ_clicked(self,checked):  
      self.ax3D.invert_zaxis()  #toggle
      self.ui.widgetPlot.redraw()

   @pyqtSlot(bool)
   def on_chkBox3D_gridOn_clicked(self,checked):  
      self.ax3D.grid(checked)  
      self.ui.widgetPlot.redraw()

   @pyqtSlot(bool)
   def on_chkBox3D_axisOn_clicked(self,checked):  
      if checked:
         self.ax3D.set_axis_on()  
      else:
         self.ax3D.set_axis_off()  
      self.ui.widgetPlot.redraw()

   @pyqtSlot(int)
   def on_combo3D_type_currentIndexChanged(self,index):  #
      self.ax3D.clear()
      if index==0:   # 3D surface
         normDef=mpl.colors.Normalize(vmin=self._Z.min(), vmax=self._Z.max())
         series3D = self.ax3D.plot_surface(self._X, self._Y, self._Z,
                           cmap=self.__colormap, linewidth=1, picker=True,
                           norm=normDef)
         self.ax3D.set_title("3D surface")
      elif index==1:  # 3D wireframe
         series3D = self.ax3D.plot_wireframe(self._X, self._Y, self._Z,
                           cmap=self.__colormap, linewidth=1, picker=True)
         self.ax3D.set_title("3D wireframe")
      elif index==2:   # 3D scatter 
         series3D = self.ax3D.scatter(self._X, self._Y, self._Z,
                           s=15, c='r', picker=True)
         self.ax3D.set_title("3D scatter")

      self.ax3D.set_xlabel("axis-X")
      self.ax3D.set_ylabel("axis-Y")
      self.ax3D.set_zlabel("axis-Z")

      self.ui.widgetPlot.redraw()


   @pyqtSlot(int)
   def on_combo2D_color_currentIndexChanged(self, index):
      if hasattr(self, "ax2D"):

         self.ax2D.clear()
         self.ax2D.set_prop_cycle(cycler('color', self.cmDict2d[index]))

         for i in range(self.xy.shape[0]):
            self.ax2D.plot(self.x, self.xy[i])

         self.ax2D.set_xlabel("axis-X")
         self.ax2D.set_ylabel("axis-Y")
         self.ui.widgetPlot.redraw()


   @pyqtSlot(str)
   def do_comboColormap_Changed(self, arg1):
      self.__colormap=mpl.cm.get_cmap(arg1)
      self.__labCmp.setText("colormap="+arg1)

      index=self.ui.combo3D_type.currentIndex()
      self.on_combo3D_type_currentIndexChanged(index)
      self.ui.chkBox3D_invertZ.setChecked(False)
      self.ui.chkBox3D_gridOn.setChecked(True)
      self.ui.chkBox3D_axisOn.setChecked(True)


      self.on_combo2D_color_currentIndexChanged(self.ui.combo2D_color.currentIndex())

   def do_canvas_mouseMove(self, event):
      if event.inaxes==self.ax2D:
         info="2D plot(x,y)=(%.2f, %.2f)"%(event.xdata,event.ydata)
      elif event.inaxes==self.ax3D:
         info="3D plot(x,y)=(%.2f, %.2f)"%(event.xdata,event.ydata)
      else:
         info=""
      self.__labMove.setText(info)
      
   def do_canvas_pick(self, event):
      info="picked artist="+event.artist.__class__.__name__
      self.__labPick.setText(info)

   def close(self) -> bool:
      self.ui.widgetPlot.figure.clear()
      self.close()
    
   

if  __name__ == "__main__":
   app = QApplication(sys.argv)
   form=myPlotWindow()
   form.show()
   sys.exit(app.exec_())
