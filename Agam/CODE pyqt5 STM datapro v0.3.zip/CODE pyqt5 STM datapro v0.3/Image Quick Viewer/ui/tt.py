from matplotlib.colors import  LinearSegmentedColormap
import numpy as np
import pickle
import pyqtgraph as pg
# color_list = np.loadtxt(r"C:\Users\DAN\OneDrive\Document\myCode\STM softeware\pyinstall\Image Processor\model\RAINBOW.PAL")
# colors = []
# for i, color in enumerate(color_list):
#     colors.append((color[0], color[1], color[2]))
# rainbow = LinearSegmentedColormap.from_list('cmap', colors, 256)
# rrainbow = LinearSegmentedColormap.from_list('cmap', colors[::-1], 256)

# rrainbow = pg.ColorMap(np.linspace(0,1,235), colors)

# print(rrainbow)
# print(rrainbow.getLookupTable(nPts=256))

# with open(r"C:\\Users\\DAN\\OneDrive\\Document\\myCode\\STM softeware\\pyinstall\\Image Processor\\model\\RRAINBOW.CMAP", 'wb') as output:
#     pickle.dump(rrainbow, output, pickle.HIGHEST_PROTOCOL)  # Save data

# with open(r"C:\\Users\\DAN\\OneDrive\\Document\\myCode\\STM softeware\\pyinstall\\Image Quick Viewer\\model\\RRAINBOW.CMAP", 'rb') as input:
#     cmap = pickle.load(input)
#
# print(cmap)



def char_to_bits(char, nbits=8):

    value = ord(char)

    ## method No1
    # NotImplementedError: only slices with step=1 (aka None) are supported
    # return [int(d) for d in str(bin(value))[-1:-8:-1]] + [0]

    ## method No2
    bval = [int(d) for d in str(bin(value))[2:]]
    if len(bval) < 8:
        bval = [0] * (8-len(bval)) + bval
    return list(reversed(bval))



def bits_to_char(bits):

    ## method No1
    # NotImplementedError: only slices with step=1 (aka None) are supported
    # result = int("".join(str(i) for i in bits[::-1]), 2)
    # return chr(result)

    ## method No2
    result = int("".join(str(i) for i in list(reversed(bits))), 2)
    return chr(result)

print(char_to_bits('H'))
print(bits_to_char([0, 0, 0, 1, 0, 0, 1, 0]))



import os
import openai

openai.api_key = "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"

start_sequence = "\nA:"
restart_sequence = "\n\nQ: "
while True:
    prompt = input(restart_sequence)
    if prompt == "quit":
        break
    else:
        try:
            response = openai.Completion.create(
              model="text-davinci-003",
              prompt = prompt,
              temperature=0,
              max_tokens=100,
              top_p=1,
              frequency_penalty=0,
              presence_penalty=0,
              # stop=["\n"]
            )
            print(start_sequence, response["choices"][0]["text"].strip())
        except Exception as exc:
            print(exc)