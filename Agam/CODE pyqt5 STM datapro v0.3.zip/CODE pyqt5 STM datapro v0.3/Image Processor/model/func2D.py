# -*- coding: utf-8 -*-
"""
@Date     : 2021/4/12 17:17:48
@Author   : milier00
@FileName : func2D.py
"""
from math import floor
import numpy as np
import copy
# from scipy.io import savemat
import os
from scipy.ndimage import rotate

class myFunc():

    def __init__(self):
        super().__init__()

    def delete_bad_point(self, img, max, min):
        """ rewrite version of smooth_sts_mapping
            average max and min points determined at the beginning
            faster than old version
        """
        tmp = copy.deepcopy(img)
        max_num = floor(img.shape[0] * img.shape[1] * max)  # num of maximum points to be smoothed
        min_num = floor(img.shape[0] * img.shape[1] * min)  # num of minimum points to be smoothed
        max_indices = [np.unravel_index(xy, img.shape) for xy in img.flatten().argsort()[-max_num:][::-1]]
        min_indices = [np.unravel_index(xy, img.shape) for xy in img.flatten().argsort()[:min_num][::-1]]
        indices = max_indices + min_indices

        for xy in indices:
            if ((xy[0] == 0) + (xy[0] == img.shape[0] - 1)) * ((xy[1] == 0) + (xy[1] == img.shape[1] - 1)):
                tmp[xy] = (img[xy[0] + 1 if xy[0] == 0 else xy[0] - 1, xy[1]] + img[
                    xy[0], xy[1] + 1 if xy[1] == 0 else xy[1] - 1]) / 2
            elif ((xy[0] == 0) + (xy[0] == img.shape[0] - 1)) * ((xy[1] != 0) * (xy[1] != img.shape[1] - 1)):
                tmp[xy] = (img[xy[0], xy[1] + 1] + img[xy[0], xy[1] - 1]) / 2
            elif ((xy[0] != 0) * (xy[0] != img.shape[0] - 1)) * ((xy[1] == 0) + (xy[1] == img.shape[1] - 1)):
                tmp[xy] = (img[xy[0] - 1, xy[1]] + img[xy[0] + 1, xy[1]]) / 2
            else:
                tmp[xy] = (img[xy[0], xy[1] + 1] + img[xy[0], xy[1] - 1] + img[xy[0] - 1, xy[1]] + img[
                    xy[0] + 1, xy[1]]) / 4

        return tmp

    def delete_bad_point2(self, img, max, min):
        """
            this one replace all bad points with global mean
        """
        tmp = copy.deepcopy(img)
        max_num = floor(img.shape[0] * img.shape[1] * max)  # num of maximum points to be smoothed
        min_num = floor(img.shape[0] * img.shape[1] * min)  # num of minimum points to be smoothed
        max_indices = [np.unravel_index(xy, img.shape) for xy in img.flatten().argsort()[-max_num:][::-1]]
        min_indices = [np.unravel_index(xy, img.shape) for xy in img.flatten().argsort()[:min_num][::-1]]
        indices = max_indices + min_indices

        for xy in indices:
            tmp[xy] = np.average(img)

        return tmp

    def symmetry(self, data, order):
        p1 = copy.deepcopy(data)
        if order == 2:
            p2 = rotate(data, 180, reshape=False, mode='nearest')
            result = (p1+p2)/2
        elif order == 3:
            p2 = rotate(data, 120, reshape=False, mode='nearest')
            p3 = rotate(data, 240, reshape=False, mode='nearest')
            result = (p1+p2+p3)/3
        elif order == 4:
            p2 = rotate(data, 90, reshape=False, mode='nearest')
            p3 = rotate(data, 180, reshape=False, mode='nearest')
            p4 = rotate(data, 270, reshape=False, mode='nearest')
            result = (p1+p2+p3+p4)/4
        elif order == 5:
            p2 = rotate(data, 72, reshape=False, mode='nearest')
            p3 = rotate(data, 144, reshape=False, mode='nearest')
            p4 = rotate(data, 216, reshape=False, mode='nearest')
            p5 = rotate(data, 288, reshape=False, mode='nearest')
            result = (p1+p2+p3+p4+p5)/5
        elif order == 6:
            p2 = rotate(data, 60, reshape=False, mode='nearest')
            p3 = rotate(data, 120, reshape=False, mode='nearest')
            p4 = rotate(data, 180, reshape=False, mode='nearest')
            p5 = rotate(data, 240, reshape=False, mode='nearest')
            p6 = rotate(data, 300, reshape=False, mode='nearest')
            result = (p1+p2+p3+p4+p5+p6)/6
        return result

    # joint density of state
    def jdos(self, matrix):
        (x, y) = matrix.shape
        jdos = np.zeros((2 * x - 1, 2 * y - 1))
        temp = np.zeros((x, y))
        avg = np.average(matrix)
        for i in range(x):
            for j in range(y):
                if matrix[i, j] < avg * .01:
                    continue
                else:
                    temp = matrix[i, j] * matrix
                    jdos[x - i - 1:2 * x - i - 1, y - j - 1:2 * y - j - 1] = jdos[x - i - 1:2 * x - i - 1,
                                                                             y - j - 1:2 * y - j - 1] + temp
        jdos[x - 1, y - 1] = 0
        return jdos






