# -*- coding: utf-8 -*-
"""
@Date     : 4/5/2024 22:49:10
@Author   : milier00
@FileName : cc.py
"""
import pickle
import imageio
import copy
import numpy as np
import cv2
# data_path = 'C:/Users/DAN/Desktop/nstm/1103220a.nstm'
data_path = 'G:/My Drive/STM1_Raw_Data/Ag100/11102300.nstm'
with open(data_path, 'rb') as input:
    data = pickle.load(input)
data2save = copy.deepcopy(data.data)
image = (255 * (data2save[0] - data2save[0].min()) / (data2save[0].max() - data2save[0].min())).astype(np.uint8)  # 或 np.uint16



# img = cv2.imread("path_to_your_image.jpg")
img_nearest = cv2.resize(image, (400, 400), interpolation=cv2.INTER_NEAREST)  # 最近邻插值
# img_linear = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_LINEAR)  # 双线性插值
# img_cubic = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_CUBIC)  # 双三次插值
# img_lanczos = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_LANCZOS4)  # Lanczos 插值


imageio.v3.imwrite('C:/Users/wh740/OneDrive/Desktop/ccc/1103220a.png', image)
# imageio.v3.imwrite('C:/Users/DAN/Desktop/nstm/1101220a.png', image)